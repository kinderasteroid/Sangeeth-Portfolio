# Responsive landing page using HTML CSS & JavaScript

### [Watch it on YouTube](https://youtu.be/RdCJmh_Hi5k)

#### Responsive landing page using HTML CSS & JavaScript

![Responsive-landing-page](https://user-images.githubusercontent.com/57999016/136793287-eebafb08-e294-489c-a597-0dbd1d0649cb.png)




